<?php
$host = "Localhost";
$user = "root";
$password = "";
$db = "plataforma_cursos";
$con= mysqli_connect($host, $user, $password,$db);
?>